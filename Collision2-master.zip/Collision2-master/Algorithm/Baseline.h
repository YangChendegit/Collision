#ifndef BASELINE_H
#define BASELINE_H

#include "Abstract.h"
#include "StreamSummary.h"

#endif
